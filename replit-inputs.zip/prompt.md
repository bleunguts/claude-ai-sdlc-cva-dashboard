Build a single-page React + TypeScript (Vite) app: a dense CVA-by-counterparty monitor, matching the attached screenshot `UI-stitch.jpg` (light theme, Bloomberg/AG Grid trading-terminal density, not consumer SaaS).

**Data:** load the attached `mock-data.json` (20 rows) as a static import. No backend, database, auth, routing or API calls. Fields: counterparty, lei, bucket, cdsSpreadBps, tenor, cvaCharge, timestamp (ISO-8601 UTC). `cdsSpreadBps` and `cvaCharge` can be `null`: render those as "—", never crash, and exclude them from totals.

**UI:** one page only, with a title bar and a filter bar above a table. No sidebar nav, KPI cards, charts, drawers, modals or notifications. Filters, all client-side: counterparty text search, bucket (All / G-SIBs / Sovereigns / Corporates / Commodities), date range on timestamp. Sortable columns. Table columns: counterparty, bucket, CDS spread (bps), tenor, CVA charge, timestamp.

**Density:** row height 26px, monospace right-aligned numerics, 1px gridlines, no card containers or shadows, ~25 rows visible without scrolling.

**Structure:** put the table in its own `CvaGrid` component that takes `rows` as props, with no data loading or filter state inside it, so it can be isolated in Storybook later. Define a typed `CvaRow` interface. Keep filter state in the parent. Add a short `README.md` with run instructions.

Do not add features beyond this.
